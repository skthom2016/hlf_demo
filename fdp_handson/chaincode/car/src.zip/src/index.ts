/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { CarAssetContract } from './car-asset-contract';
export { CarAssetContract } from './car-asset-contract';

export const contracts: any[] = [ CarAssetContract ];
